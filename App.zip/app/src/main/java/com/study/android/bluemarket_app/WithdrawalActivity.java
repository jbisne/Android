package com.study.android.bluemarket_app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class WithdrawalActivity extends AppCompatActivity
{
    private static final String TAG = "teamproject";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        Log.d(TAG, "회원탈퇴 액티비티");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_withdrawal);

    }
}

package com.study.android.bluemarket_app;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class SaleList extends Fragment
{
    private static final String TAG = "teamproject";

    SaleAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState)
    {
        Log.d(TAG,"판매 리스트 출력");

        adapter = new SaleAdapter(getContext());
        // 여기! new SaleAdapter(this);인데 getContext()넣으니까 된다!

        SaleItem item1 = new SaleItem("모모", "24", R.drawable.momo);
        adapter.addItem(item1);

        SaleItem item2 = new SaleItem("슬기", "24", R.drawable.sul1);
        adapter.addItem(item2);

        View view = inflater.inflate(R.layout.fragment_salelist, null) ;

        ListView listview = (ListView) view.findViewById(R.id.saleList) ;
        listview.setAdapter(adapter) ;

        return view;
    }

}



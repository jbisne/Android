package com.study.android.bluemarket_app;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class WriteActivity extends AppCompatActivity
{
    private static final String TAG = "teamproject";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        Log.d(TAG ,"글쓰기 화면");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write);

        Button button = findViewById(R.id.BackButton);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });
        Log.d(TAG ,"뒤로가기");
    }

}
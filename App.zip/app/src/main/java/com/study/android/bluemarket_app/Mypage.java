package com.study.android.bluemarket_app;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class Mypage extends Fragment
{
    private static final String TAG = "teamproject";
//    여기다가 전역변수로 지저해놓으니까 APP이 아예 튕긴다!!
//    Fragment는 이러는듯? 잘 기억해둘것!
//    final String[] items = {"YES", "NO"};
//
//    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState)
    {
        ViewGroup rootView =
                (ViewGroup) inflater.inflate(R.layout.fragment_mypage, container, false);

        // button1 = 정보수정
        Button button1 = rootView.findViewById(R.id.modifyButton);
        button1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(getActivity(),ModifyActivity.class);
                startActivity(intent);
            }
        });

        // button2 = 로그아웃 Alert창 띄우기
        Button button2 = rootView.findViewById(R.id.logOutButton);
        button2.setOnClickListener(new View.OnClickListener()
        {
            final String[] items = {"예", "아니오"};

            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

            @Override
            public void onClick(View v)
            {

                builder.setTitle("로그아웃 하시겠습니까?");
                builder.setItems(items, new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        if(which ==0)
                        {
                            /*..YES..*/
                            Intent intent = new Intent(getActivity(),MainActivity.class);
                            startActivity(intent);
                        }
                        else
                        {
                            /*...NO...*/
                        }
                    }
                });

                builder.show();
            }
        });

        Button button3 = rootView.findViewById(R.id.withdrawalButton);
        button3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(getActivity(),WithdrawalActivity.class);
                startActivity(intent);
            }
        });

        return rootView;
    }


}

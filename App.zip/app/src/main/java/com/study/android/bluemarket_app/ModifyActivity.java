package com.study.android.bluemarket_app;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

public class ModifyActivity extends AppCompatActivity
{
    private static final String TAG = "teamproject";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        Log.d(TAG, "정보수정 액티비티");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);
    }
}
